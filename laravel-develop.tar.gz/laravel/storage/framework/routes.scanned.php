<?php 

$router->get('/', [
	'uses' => 'App\Http\Controllers\HomeController@index',
	'as' => NULL,
	'middleware' => [],
	'where' => [],
	'domain' => NULL,
]);

$router->get('auth/register', [
	'uses' => 'App\Http\Controllers\Auth\AuthController@showRegistrationForm',
	'as' => NULL,
	'middleware' => ['guest'],
	'where' => [],
	'domain' => NULL,
]);

$router->post('auth/register', [
	'uses' => 'App\Http\Controllers\Auth\AuthController@register',
	'as' => NULL,
	'middleware' => ['guest'],
	'where' => [],
	'domain' => NULL,
]);

$router->get('auth/login', [
	'uses' => 'App\Http\Controllers\Auth\AuthController@showLoginForm',
	'as' => NULL,
	'middleware' => ['guest'],
	'where' => [],
	'domain' => NULL,
]);

$router->post('auth/login', [
	'uses' => 'App\Http\Controllers\Auth\AuthController@login',
	'as' => NULL,
	'middleware' => ['guest'],
	'where' => [],
	'domain' => NULL,
]);

$router->get('auth/logout', [
	'uses' => 'App\Http\Controllers\Auth\AuthController@logout',
	'as' => NULL,
	'middleware' => [],
	'where' => [],
	'domain' => NULL,
]);

$router->get('password/email', [
	'uses' => 'App\Http\Controllers\Auth\PasswordController@showResetRequestForm',
	'as' => NULL,
	'middleware' => ['guest'],
	'where' => [],
	'domain' => NULL,
]);

$router->post('password/email', [
	'uses' => 'App\Http\Controllers\Auth\PasswordController@sendResetLink',
	'as' => NULL,
	'middleware' => ['guest'],
	'where' => [],
	'domain' => NULL,
]);

$router->get('password/reset/{token}', [
	'uses' => 'App\Http\Controllers\Auth\PasswordController@showResetForm',
	'as' => NULL,
	'middleware' => ['guest'],
	'where' => [],
	'domain' => NULL,
]);

$router->post('password/reset', [
	'uses' => 'App\Http\Controllers\Auth\PasswordController@resetPassword',
	'as' => NULL,
	'middleware' => ['guest'],
	'where' => [],
	'domain' => NULL,
]);
