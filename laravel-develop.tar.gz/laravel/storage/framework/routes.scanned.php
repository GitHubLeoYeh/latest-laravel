<?php 

$router->get('/', ['uses' => 'App\Http\Controllers\HomeController@index', 'domain' => NULL, 'as' => 'home', 'middleware' => array (
), 'where' => array (
)]);
$router->get('auth/register', ['uses' => 'App\Http\Controllers\Auth\AuthController@showRegistrationForm', 'domain' => NULL, 'as' => NULL, 'middleware' => array (
  0 => 'csrf',
  1 => 'guest',
), 'where' => array (
)]);
$router->post('auth/register', ['uses' => 'App\Http\Controllers\Auth\AuthController@register', 'domain' => NULL, 'as' => NULL, 'middleware' => array (
  0 => 'csrf',
  1 => 'guest',
), 'where' => array (
)]);
$router->get('auth/login', ['uses' => 'App\Http\Controllers\Auth\AuthController@showLoginForm', 'domain' => NULL, 'as' => NULL, 'middleware' => array (
  0 => 'csrf',
  1 => 'guest',
), 'where' => array (
)]);
$router->post('auth/login', ['uses' => 'App\Http\Controllers\Auth\AuthController@login', 'domain' => NULL, 'as' => NULL, 'middleware' => array (
  0 => 'csrf',
  1 => 'guest',
), 'where' => array (
)]);
$router->get('auth/logout', ['uses' => 'App\Http\Controllers\Auth\AuthController@logout', 'domain' => NULL, 'as' => NULL, 'middleware' => array (
  0 => 'csrf',
), 'where' => array (
)]);
$router->get('password/email', ['uses' => 'App\Http\Controllers\Auth\PasswordController@showResetRequestForm', 'domain' => NULL, 'as' => NULL, 'middleware' => array (
  0 => 'csrf',
  1 => 'guest',
), 'where' => array (
)]);
$router->post('password/email', ['uses' => 'App\Http\Controllers\Auth\PasswordController@sendResetLink', 'domain' => NULL, 'as' => NULL, 'middleware' => array (
  0 => 'csrf',
  1 => 'guest',
), 'where' => array (
)]);
$router->get('password/reset', ['uses' => 'App\Http\Controllers\Auth\PasswordController@showResetForm', 'domain' => NULL, 'as' => NULL, 'middleware' => array (
  0 => 'csrf',
  1 => 'guest',
), 'where' => array (
)]);
$router->post('password/reset', ['uses' => 'App\Http\Controllers\Auth\PasswordController@resetPassword', 'domain' => NULL, 'as' => NULL, 'middleware' => array (
  0 => 'csrf',
  1 => 'guest',
), 'where' => array (
)]);
